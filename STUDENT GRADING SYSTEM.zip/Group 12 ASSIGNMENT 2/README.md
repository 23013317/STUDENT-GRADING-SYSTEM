# Student Grading System README

## Table of Contents



<!-- TOC -->
* [Student Grading System README](#student-grading-system-readme)
  * [Table of Contents](#table-of-contents)
* [Student Grading System](#student-grading-system)
  * [Features](#features)
  * [Getting Started](#getting-started)
  * [System Requirements](#system-requirements)
    * [Hardware Requirements](#hardware-requirements)
    * [Software Requirements](#software-requirements)
    * [Additional Requirements](#additional-requirements)
  * [Installation](#installation)
    * [Step 1: Install Java Development Kit (JDK)](#step-1-install-java-development-kit-jdk)
    * [Step 2: Open the Executable JAR File](#step-2-open-the-executable-jar-file)
    * [Step 3: Run the Executable JAR File](#step-3-run-the-executable-jar-file)
  * [configuration](#configuration)
    * [Logging in as a Lecture](#logging-in-as-a-lecture)
  * [For how to use and more details please view the  `User Manual`](#for-how-to-use-and-more-details-please-view-the-user-manual)
  * [Contributers](#contributers)
  * [//-------------------------------------End ------------------------------------//](#-------------------------------------end-------------------------------------)
<!-- TOC -->








# Student Grading System

Welcome to the Student Grading System! This desktop application is designed to help educational institutions manage student grades efficiently. Built using Java Swing for the graphical user interface and MySQL for the database, this system provides a user-friendly platform for administrators and teachers to handle student information, courses, and grades.

## Features

- **Student Management**: Add, update, and delete student records.
- **Course Management**: Manage course details and assign them to students.
- **Grade Calculation**: Automatically calculate grades based on predefined criteria.
- **User Authentication**: Secure login for administrators and teachers.
- **Reports**: Generate and export grade reports for individual students or entire classes.

## Getting Started

To get started with the Student Grading System, follow the installation instructions below.



## System Requirements

To run the Student Grading System, ensure your environment meets the following requirements:

### Hardware Requirements

- **Processor**: Dual-core processor or higher
- **RAM**: 4 GB or more
- **Storage**: At least 500 MB of free disk space

### Software Requirements

- **Operating System**: Windows 7 or later, macOS 10.12 or later, or any Linux distribution with GUI support
- **Java Development Kit (JDK)**: Version 11 or higher
- **SQLite**: Version 3.0 or higher
- **SQLite JDBC Driver**: Version 3.36.0 or higher
- **IDE**: Any Java-compatible Integrated Development Environment (IDE) such as IntelliJ IDEA, Eclipse, or NetBeans

### Additional Requirements

- **Internet Connection**: Required for downloading dependencies and updates
- **Permissions**: Administrative privileges for installation and configuration

Ensure all the above requirements are met before installing and running the application.



## Installation

Follow these steps to install and set up the Student Grading System:

### Step 1: Install Java Development Kit (JDK)

Ensure you have JDK 11 or higher installed on your system. You can download it from the Oracle website or use a package manager like `apt` for Linux or `brew` for macOS.

### Step 2: Open the Executable JAR File

on the Package  `student-grading-system_002` file from the provided source.
open the `executable .jar file`
### Step 3: Run the Executable JAR File

Run the file ...view the source code on the main folder


## configuration

### Logging in as a Lecture
>To login as a Lecture the Default Username is `a` and Password `a`

>To login as a dummy Student Username is `a` and Password `a`


## For how to use and more details please view the  `User Manual`



## Contributers
```chatinput
MAFUNZWAINI UT 

MANYUA I 
NEMATSWERANI 
MAKHUVHA L 
NEMAKONDE E 
```

## //-------------------------------------End ------------------------------------//