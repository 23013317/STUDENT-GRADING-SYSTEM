import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ManageStudentsPanel extends JPanel {
    private DefaultTableModel studentTableModel;
    private JTable studentTable;
    private JButton editStudentButton;
    private JButton deleteStudentButton;

    public ManageStudentsPanel() {
        setLayout(new BorderLayout());

        // Student table
        studentTableModel = new DefaultTableModel(new String[]{"ID", "Name"}, 0);
        studentTable = new JTable(studentTableModel);
        loadStudentsFromDatabase();
        add(new JScrollPane(studentTable), BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel();
        editStudentButton = new JButton("Edit Student");
        deleteStudentButton = new JButton("Delete Student");
        buttonPanel.add(editStudentButton);
        buttonPanel.add(deleteStudentButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Button actions
        editStudentButton.addActionListener(new EditStudentButtonListener());
        deleteStudentButton.addActionListener(new DeleteStudentButtonListener());
    }

    private void loadStudentsFromDatabase() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, username FROM students")) {

            while (rs.next()) {
                studentTableModel.addRow(new Object[]{rs.getInt("id"), rs.getString("username")});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private class EditStudentButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = studentTable.getSelectedRow();
            if (selectedRow != -1) {
                int studentId = (int) studentTableModel.getValueAt(selectedRow, 0);
                String newName = JOptionPane.showInputDialog("Enter new name:");
                if (newName != null && !newName.trim().isEmpty()) {
                    updateStudentInDatabase(studentId, newName);
                    studentTableModel.setValueAt(newName, selectedRow, 1);
                }
            } else {
                JOptionPane.showMessageDialog(ManageStudentsPanel.this, "Please select a student to edit.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private class DeleteStudentButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = studentTable.getSelectedRow();
            if (selectedRow != -1) {
                int studentId = (int) studentTableModel.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(ManageStudentsPanel.this, "Are you sure you want to delete this student?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    deleteStudentFromDatabase(studentId);
                    studentTableModel.removeRow(selectedRow);
                }
            } else {
                JOptionPane.showMessageDialog(ManageStudentsPanel.this, "Please select a student to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updateStudentInDatabase(int studentId, String newName) {
        String updateSQL = "UPDATE students SET username = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {

            pstmt.setString(1, newName);
            pstmt.setInt(2, studentId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteStudentFromDatabase(int studentId) {
        String deleteGradesSQL = "DELETE FROM grades WHERE student_id = ?";
        String deleteCoursesSQL = "DELETE FROM student_courses WHERE student_id = ?";
        String deleteStudentSQL = "DELETE FROM students WHERE id = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db")) {
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement pstmtGrades = conn.prepareStatement(deleteGradesSQL);
                 PreparedStatement pstmtCourses = conn.prepareStatement(deleteCoursesSQL);
                 PreparedStatement pstmtStudent = conn.prepareStatement(deleteStudentSQL)) {

                pstmtGrades.setInt(1, studentId);
                pstmtGrades.executeUpdate();

                pstmtCourses.setInt(1, studentId);
                pstmtCourses.executeUpdate();

                pstmtStudent.setInt(1, studentId);
                pstmtStudent.executeUpdate();

                conn.commit(); // Commit transaction
            } catch (SQLException e) {
                conn.rollback(); // Rollback transaction on error
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
