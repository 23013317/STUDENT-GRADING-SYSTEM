import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Map;

    public class CourseReportPanel extends JPanel {
        private final JList<String> courseList;
        private final JTable reportTable;
        private final DefaultTableModel tableModel;
        private final Map<String, CourseReportDatabaseFetcher.CourseData> courseDataMap;

        public CourseReportPanel() {
            setLayout(new BorderLayout());

            // Fetch course data from database
            CourseReportDatabaseFetcher fetcher = new CourseReportDatabaseFetcher();
            courseDataMap = fetcher.fetchCourseData();

            // Create course list
            DefaultListModel<String> listModel = new DefaultListModel<>();
            for (String course : courseDataMap.keySet()) {
                listModel.addElement(course);
            }
            courseList = new JList<>(listModel);
            courseList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            courseList.addListSelectionListener(e -> updateReportTable());

            // Create report table
            String[] columnNames = {"Course Name", "Test 1 Avg", "Test 2 Avg", "Assign Avg", "Semester Avg", "Exam Avg", "Final Avg", "Students Enrolled"};
            tableModel = new DefaultTableModel(columnNames, 0);
            reportTable = new JTable(tableModel);

            // Add components to panel
            add(new JScrollPane(courseList), BorderLayout.WEST);
            add(new JScrollPane(reportTable), BorderLayout.CENTER);
        }

        private void updateReportTable() {
            String selectedCourse = courseList.getSelectedValue();
            if (selectedCourse != null) {
                CourseReportDatabaseFetcher.CourseData data = courseDataMap.get(selectedCourse);
                tableModel.setRowCount(0); // Clear existing rows
                tableModel.addRow(new Object[]{
                        data.courseName,
                        data.test1Avg,
                        data.test2Avg,
                        data.assignAvg,
                        data.semesterAvg,
                        data.examAvg,
                        data.finalAvg,
                        data.studentsEnrolled
                });
            }
        }

    }

