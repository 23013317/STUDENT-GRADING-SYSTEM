import javax.swing.*;
import java.awt.*;

public class AdminFrame extends JFrame {
    private final CardLayout cardLayout;
    private final JPanel mainPanel;


    public AdminFrame() {

        setTitle("STUDENT GRADING SYS_24");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        MenuBarSet.addMenuBar(this);

        // North panel with buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 4));
        buttonPanel.setBackground(Color.lightGray);

        JButton button1 = new JButton("Manage Courses");
        button1.setBackground(Color.lightGray);
        button1.setForeground(Color.black);
        button1.setFocusable(true);
        button1.setBorder(BorderFactory.createRaisedBevelBorder());

        JButton button2 = new JButton("Manage Grades");
        button2.setBackground(Color.lightGray);
        button2.setForeground(Color.black);
        button2.setBorder(BorderFactory.createRaisedBevelBorder());

        JButton button3 = new JButton("Student Reports");
        button3.setBackground(Color.lightGray);
        button3.setForeground(Color.black);
        button3.setBorder(BorderFactory.createRaisedSoftBevelBorder());

        JButton button4 = new JButton("Manage Students");
        button4.setBackground(Color.lightGray);
        button4.setForeground(Color.black);
        button4.setBorder(BorderFactory.createRaisedBevelBorder());

        buttonPanel.add(button1);
        buttonPanel.add(button2);
        buttonPanel.add(button3);
        buttonPanel.add(button4);

        // Main panel with CardLayout
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // Adding views to the main panel

        mainPanel.add(new JLabel("Welcome to the Admin Panel", SwingConstants.CENTER), "welcome");
        mainPanel.add(new ManageCoursesPanel(), "manageCourses");
        mainPanel.add(new ManageGradesPanel(), "manageGrades");
        mainPanel.add(new CourseReportPanel(), "studentReports");
        mainPanel.add(new ManageStudentsPanel(),"manageStudents");

        // Button actions
        button1.addActionListener(e -> cardLayout.show(mainPanel, "manageCourses"));
        button2.addActionListener(e -> cardLayout.show(mainPanel, "manageGrades"));
        button3.addActionListener(e -> cardLayout.show(mainPanel, "studentReports"));
        button4.addActionListener(e ->cardLayout.show(mainPanel, "manageStudents"));

        // Adding components to the frame
        add(buttonPanel, BorderLayout.NORTH);

        add(mainPanel, BorderLayout.CENTER);

        // Show welcome view initially
        cardLayout.show(mainPanel, "welcome");

        setVisible(true);
    }


}

