import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ManageGradesPanel extends JPanel {
    private DefaultListModel<String> studentListModel;
    private JList<String> studentList;
    private DefaultTableModel gradesTableModel;
    private JTable gradesTable;
    private JButton addGradeButton;
    private JButton removeGradeButton;
    private JButton editGradeButton;

    public ManageGradesPanel() {

        setLayout(new BorderLayout());

        // Student list
        studentListModel = new DefaultListModel<>();
        studentList = new JList<>(studentListModel);

        studentList.setBackground(Color.lightGray);
        studentList.setBorder(BorderFactory.createLineBorder(Color.black));
        studentList.setCellRenderer(new CustomListCellRenderer());

        loadStudentsFromDatabase();

        studentList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentList.addListSelectionListener(new StudentSelectionListener());

        JScrollPane studentScrollPane = new JScrollPane(studentList);
        studentScrollPane.setPreferredSize(new Dimension(150,studentScrollPane.getPreferredSize().height));
        studentScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        studentScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(studentScrollPane, BorderLayout.WEST);

        // Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.DARK_GRAY);

        addGradeButton = new JButton("Add Grade");
        addGradeButton.setFocusable(false);
        addGradeButton.setBackground(Color.lightGray);
        addGradeButton.setForeground(Color.black);
        addGradeButton.setBorder(BorderFactory.createRaisedBevelBorder());

        removeGradeButton = new JButton("Remove Grade");
        removeGradeButton.setFocusable(false);
        removeGradeButton.setBackground(Color.lightGray);
        removeGradeButton.setForeground(Color.black);
        removeGradeButton.setBorder(BorderFactory.createRaisedBevelBorder());

        editGradeButton = new JButton("Edit Grade");
        editGradeButton.setFocusable(false);
        editGradeButton.setBackground(Color.lightGray);
        editGradeButton.setForeground(Color.black);
        editGradeButton.setBorder(BorderFactory.createRaisedBevelBorder());

        buttonPanel.add(addGradeButton);
        buttonPanel.add(removeGradeButton);
        buttonPanel.add(editGradeButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Grades table
        gradesTableModel = new DefaultTableModel(new String[]{"Course", "Test1", "Test2", "Assignment1", "Semester Mark", "Exam Mark", "Final Mark"}, 0);
        gradesTable = new JTable(gradesTableModel);
        JScrollPane gradesScrollPane = new JScrollPane(gradesTable);
        gradesScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(gradesScrollPane, BorderLayout.CENTER);

        // Button actions
        addGradeButton.addActionListener(new AddGradeButtonListener());
        removeGradeButton.addActionListener(new RemoveGradeButtonListener());
        editGradeButton.addActionListener(new EditGradeButtonListener());
    }

// creating split cells on the JTExt ARea

    static class CustomListCellRenderer extends DefaultListCellRenderer {
        private final Border lineBorder = BorderFactory.createLineBorder(Color.BLACK, 1);

        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            label.setBorder(lineBorder);
            return label;
        }
    }

    private void loadStudentsFromDatabase() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT username FROM students")) {

            while (rs.next()) {
                studentListModel.addElement(rs.getString("username"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadGradesForStudent(String studentName) {
        gradesTableModel.setRowCount(0); // Clear existing data
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement pstmt = conn.prepareStatement("SELECT course, test1, test2, assignment1, semester_mark, exam_mark, final_mark FROM grades WHERE student_id = (SELECT id FROM students WHERE username = ?)")) {

            pstmt.setString(1, studentName);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                gradesTableModel.addRow(new Object[]{
                        rs.getString("course"),
                        rs.getDouble("test1"),
                        rs.getDouble("test2"),
                        rs.getDouble("assignment1"),
                        rs.getDouble("semester_mark"),
                        rs.getDouble("exam_mark"),
                        rs.getDouble("final_mark")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private class StudentSelectionListener implements ListSelectionListener {
        @Override
        public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting()) {
                String selectedStudent = studentList.getSelectedValue();
                if (selectedStudent != null) {
                    loadGradesForStudent(selectedStudent);
                }
            }
        }
    }

    private class AddGradeButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String selectedStudent = studentList.getSelectedValue();
            if (selectedStudent != null) {
                // Fetch enrolled courses for the selected student
                String[] courses = getEnrolledCourses(selectedStudent);
                if (courses.length == 0) {
                    JOptionPane.showMessageDialog(ManageGradesPanel.this, "No courses found for the selected student.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Show a JComboBox for course selection
                JComboBox<String> courseComboBox = new JComboBox<>(courses);
                int result = JOptionPane.showConfirmDialog(ManageGradesPanel.this, courseComboBox, "Select Course", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    String course = (String) courseComboBox.getSelectedItem();
                    String test1 = JOptionPane.showInputDialog("Enter Test1 mark:");
                    String test2 = JOptionPane.showInputDialog("Enter Test2 mark:");
                    String assignment1 = JOptionPane.showInputDialog("Enter Assignment1 mark:");
                    String examMark = JOptionPane.showInputDialog("Enter Exam mark:");

                    if (course != null && test1 != null && test2 != null && assignment1 != null && examMark != null) {
                        double test1Mark = Double.parseDouble(test1);
                        double test2Mark = Double.parseDouble(test2);
                        double assignment1Mark = Double.parseDouble(assignment1);
                        double examMarkValue = Double.parseDouble(examMark);

                        double semesterMark = 0.3 * test1Mark + 0.3 * test2Mark + 0.4 * assignment1Mark;
                        double finalMark = 0.6 * examMarkValue + 0.4 * semesterMark;

                        gradesTableModel.addRow(new Object[]{course, test1Mark, test2Mark, assignment1Mark, semesterMark, examMarkValue, finalMark});
                        addGradeToDatabase(selectedStudent, course, test1Mark, test2Mark, assignment1Mark, semesterMark, examMarkValue, finalMark);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(ManageGradesPanel.this, "Please select a student to add grades.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    private String[] getEnrolledCourses(String studentName) {
        java.util.List<String> courses = new java.util.ArrayList<>();
        String query = "SELECT course_name FROM student_courses WHERE student_id = (SELECT id FROM students WHERE username = ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, studentName);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                courses.add(rs.getString("course_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses.toArray(new String[0]);
    }

    private class RemoveGradeButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = gradesTable.getSelectedRow();
            String selectedStudent = studentList.getSelectedValue();
            if (selectedRow != -1 && selectedStudent != null) {
                String course = (String) gradesTableModel.getValueAt(selectedRow, 0);
                gradesTableModel.removeRow(selectedRow);
                removeGradeFromDatabase(selectedStudent, course);
            } else {
                JOptionPane.showMessageDialog(ManageGradesPanel.this, "Please select a grade to remove.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private class EditGradeButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = gradesTable.getSelectedRow();
            String selectedStudent = studentList.getSelectedValue();
            if (selectedRow != -1 && selectedStudent != null) {
                String course = (String) gradesTableModel.getValueAt(selectedRow, 0);
                String test1 = JOptionPane.showInputDialog("Enter new Test1 mark:", gradesTableModel.getValueAt(selectedRow, 1));
                String test2 = JOptionPane.showInputDialog("Enter new Test2 mark:", gradesTableModel.getValueAt(selectedRow, 2));
                String assignment1 = JOptionPane.showInputDialog("Enter new Assignment1 mark:", gradesTableModel.getValueAt(selectedRow, 3));
                String examMark = JOptionPane.showInputDialog("Enter new Exam mark:", gradesTableModel.getValueAt(selectedRow, 5));

                if (test1 != null && test2 != null && assignment1 != null && examMark != null) {
                    double test1Mark = Double.parseDouble(test1);
                    double test2Mark = Double.parseDouble(test2);
                    double assignment1Mark = Double.parseDouble(assignment1);
                    double examMarkValue = Double.parseDouble(examMark);

                    double semesterMark = 0.3 * test1Mark + 0.3 * test2Mark + 0.4 * assignment1Mark;
                    double finalMark = 0.6 * examMarkValue + 0.4 * semesterMark;

                    gradesTableModel.setValueAt(test1Mark, selectedRow, 1);
                    gradesTableModel.setValueAt(test2Mark, selectedRow, 2);
                    gradesTableModel.setValueAt(assignment1Mark, selectedRow, 3);
                    gradesTableModel.setValueAt(semesterMark, selectedRow, 4);
                    gradesTableModel.setValueAt(examMarkValue, selectedRow, 5);
                    gradesTableModel.setValueAt(finalMark, selectedRow, 6);

                    updateGradeInDatabase(selectedStudent, course, test1Mark, test2Mark, assignment1Mark, semesterMark, examMarkValue, finalMark);
                }
            } else {
                JOptionPane.showMessageDialog(ManageGradesPanel.this, "Please select a grade to edit.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    private void addGradeToDatabase(String studentName, String course, double test1, double test2, double assignment1, double semesterMark, double examMark, double finalMark) {
        String insertSQL = "INSERT INTO grades (student_id, course, test1, test2, assignment1, semester_mark, exam_mark, final_mark) VALUES ((SELECT id FROM students WHERE username = ?), ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            pstmt.setString(1, studentName);
            pstmt.setString(2, course);
            pstmt.setDouble(3, test1);
            pstmt.setDouble(4, test2);
            pstmt.setDouble(5, assignment1);
            pstmt.setDouble(6, semesterMark);
            pstmt.setDouble(7, examMark);
            pstmt.setDouble(8, finalMark);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void removeGradeFromDatabase(String studentName, String course) {
        String deleteSQL = "DELETE FROM grades WHERE student_id = (SELECT id FROM students WHERE username = ?) AND course = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {

            pstmt.setString(1, studentName);
            pstmt.setString(2, course);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateGradeInDatabase(String studentName, String course, double test1, double test2, double assignment1, double semesterMark, double examMark, double finalMark) {
        String updateSQL = "UPDATE grades SET test1 = ?, test2 = ?, assignment1 = ?, semester_mark = ?, exam_mark = ?, final_mark = ? WHERE student_id = (SELECT id FROM students WHERE username = ?) AND course = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement pstmt = conn.prepareStatement(updateSQL)) {

            pstmt.setDouble(1, test1);
            pstmt.setDouble(2, test2);
            pstmt.setDouble(3, assignment1);
            pstmt.setDouble(4, semesterMark);
            pstmt.setDouble(5, examMark);
            pstmt.setDouble(6, finalMark);
            pstmt.setString(7, studentName);
            pstmt.setString(8, course);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
