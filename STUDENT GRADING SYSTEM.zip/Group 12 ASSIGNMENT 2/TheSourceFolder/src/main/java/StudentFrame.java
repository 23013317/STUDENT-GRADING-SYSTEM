import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;


public class StudentFrame extends JFrame {

    private CardLayout cardLayout;
    private JPanel cardPanel;
    private JPanel panel;
    private JList<String> courseList;
    private JTable gradesTable;
    private DefaultTableModel gradesTableModel;
    private int studentId;


        public StudentFrame() {
            setTitle("Student Frame");
            setSize(800, 600);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);
            MenuBarSet.addMenuBar(this);

            add(studentViewGradesPanel(getStudentId(new LoginFrame(studentId).getLoggedUsername())));
            setVisible(true);
        }


    private JPanel studentViewGradesPanel(int studentId) {


        JPanel panel = new JPanel();
        panel.setBackground(Color.white);

        setLayout(new BorderLayout());

        // Create buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.setBackground(Color.white);

        JButton viewGradesButton = new JButton("View Grades");
        viewGradesButton.setFocusable(false);
        viewGradesButton.setBackground(Color.lightGray);
        viewGradesButton.setForeground(Color.black);


        JButton editDetailsButton = new JButton("Home");
        editDetailsButton.setFocusable(false);
        editDetailsButton.setBackground(Color.lightGray);
        editDetailsButton.setForeground(Color.black);

        buttonPanel.add(viewGradesButton);
        buttonPanel.add(editDetailsButton);

        // Create card layout panel
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        // Create welcome panel
        JPanel welcomePanel = createWelcomePanel();
        welcomePanel.setBackground(Color.white);
        cardPanel.add(welcomePanel, "Welcome");

        // Create view grades panel

        cardPanel.add( createViewGradesPanel(), "View Grades");

        // Create empty colored panels for other buttons
        JPanel addRemoveCoursePanel = new JPanel();
        addRemoveCoursePanel.setBackground(Color.LIGHT_GRAY);
        cardPanel.add(addRemoveCoursePanel, "Add/Remove Course");

        JPanel editDetailsPanel = new JPanel();
        editDetailsPanel.setBackground(Color.CYAN);
        cardPanel.add(editDetailsPanel, "Edit Details");

        // Add panels to main panel
       panel.add(buttonPanel, BorderLayout.NORTH);
       panel.add(cardPanel);


        // Add action listeners
        viewGradesButton.addActionListener(e -> cardLayout.show(cardPanel, "View Grades"));
        editDetailsButton.addActionListener(e -> cardLayout.show(cardPanel, "Welcome"));

        // Show welcome panel initially
        cardLayout.show(cardPanel, "Welcome");

        return panel;
    }

    private JPanel createWelcomePanel() {
        JPanel panel = new JPanel(new GridLayout(1, 1));

        ImageIcon image =new ImageIcon("src/Picture1.png");

        JLabel welcomeLabel = new JLabel("Welcome to the Student Management System", JLabel.CENTER);
        welcomeLabel.setIcon(image);

        panel.add(welcomeLabel);
        return panel;
    }

    private JPanel createViewGradesPanel() {

        panel = new JPanel();
        panel.setBackground(Color.white);
        gradesTableModel = new DefaultTableModel(new String[]{"Course", "Test1", "Test2", "Assignment1", "Semester Mark", "Exam Mark", "Final Mark"}, 0);
        gradesTable = new JTable(gradesTableModel);

        JScrollPane gradesScrollPane = new JScrollPane(gradesTable);
        gradesScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        panel.add(gradesScrollPane);


        loadGradesForStudent(new LoginFrame(studentId).getLoggedUsername());


        return panel;
    }

    private void loadGradesForStudent(String studentName) {

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement pstmt = conn.prepareStatement("SELECT course, test1, test2, assignment1, semester_mark, exam_mark, final_mark FROM grades WHERE student_id = (SELECT id FROM students WHERE username = ?)")) {

            pstmt.setString(1, studentName);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                gradesTableModel.addRow(new Object[]{
                        rs.getString("course"),
                        rs.getDouble("test1"),
                        rs.getDouble("test2"),
                        rs.getDouble("assignment1"),
                        rs.getDouble("semester_mark"),
                        rs.getDouble("exam_mark"),
                        rs.getDouble("final_mark")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private int getStudentId(String username) {
        String query = "SELECT id FROM students WHERE username = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("id");
            } else {
                return -1; // Student not found
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }


}





