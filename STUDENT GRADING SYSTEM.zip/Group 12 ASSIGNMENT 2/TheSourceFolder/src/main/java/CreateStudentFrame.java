import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;

public class CreateStudentFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField fullNameField;
    private JComboBox<String> courseComboBox;
    private JTextArea selectedCoursesTextArea;
    private JButton addCourseButton;
    private JButton createButton;
    private DefaultComboBoxModel<String> courseComboBoxModel;


    public CreateStudentFrame() {
        setTitle("Create Student");
        setLayout(new GridLayout(3,1));
        setSize(700,500);

        JPanel panel = new JPanel(new GridLayout(0, 2));
        panel.setBackground(Color.lightGray);

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        panel.add(new JLabel("Full Name:"));
        fullNameField = new JTextField();
        panel.add(fullNameField);

        panel.add(new JLabel("Select Course:"));
        courseComboBoxModel = new DefaultComboBoxModel<>();
        loadCoursesFromDatabase();
        courseComboBox = new JComboBox<>(courseComboBoxModel);
        panel.add(courseComboBox);

        addCourseButton = new JButton("Add Course");
        addCourseButton.setBackground(Color.darkGray);
        addCourseButton.setForeground(Color.white);
        addCourseButton.setBorder(BorderFactory.createRaisedBevelBorder());
        addCourseButton.addActionListener(new AddCourseButtonListener());
        panel.add(addCourseButton);

        add(panel);

        selectedCoursesTextArea = new JTextArea(10, 30);
        selectedCoursesTextArea.setEditable(false);
        JScrollPane selectedCoursesScrollPane = new JScrollPane(selectedCoursesTextArea);
        add(selectedCoursesScrollPane);

        createButton = new JButton("Create");
        createButton.setBackground(Color.darkGray);
        createButton.setForeground(Color.white);
        createButton.setBorder(BorderFactory.createRaisedBevelBorder());
        createButton.addActionListener(new CreateButtonListener());
        add(createButton);
        setLocationRelativeTo(null);
        setVisible(true);
      //  pack();
    }

    private void loadCoursesFromDatabase() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT course_name FROM courses")) {

            while (rs.next()) {
                courseComboBoxModel.addElement(rs.getString("course_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    private class AddCourseButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String selectedCourse = (String) courseComboBox.getSelectedItem();
            if (selectedCourse != null && !selectedCoursesTextArea.getText().contains(selectedCourse)) {
                selectedCoursesTextArea.append(selectedCourse + "\n");
            }
        }
    }

    private class CreateButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String fullName = fullNameField.getText();
            String[] selectedCoursesArray = selectedCoursesTextArea.getText().split("\n");
            ArrayList<String> selectedCourses = new ArrayList<>(Arrays.asList(selectedCoursesArray));

            if (selectedCourses.size() > 5) {
                JOptionPane.showMessageDialog(CreateStudentFrame.this, "You can select a maximum of 5 courses.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (createStudentInDatabase(username, password, fullName, selectedCourses)) {
                JOptionPane.showMessageDialog(CreateStudentFrame.this, "Student created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(CreateStudentFrame.this, "Error creating student.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private boolean createStudentInDatabase(String username, String password, String fullName, ArrayList<String> courses) {
        String insertStudentSQL = "INSERT INTO students (username, password, full_name) VALUES (?, ?, ?)";
        String insertCourseSQL = "INSERT INTO student_courses (student_id, course_name) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             PreparedStatement studentStmt = conn.prepareStatement(insertStudentSQL, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement courseStmt = conn.prepareStatement(insertCourseSQL)) {

            conn.setAutoCommit(false);

            studentStmt.setString(1, username);
            studentStmt.setString(2, password);
            studentStmt.setString(3, fullName);
            studentStmt.executeUpdate();

            ResultSet generatedKeys = studentStmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int studentId = generatedKeys.getInt(1);

                for (String course : courses) {
                    courseStmt.setInt(1, studentId);
                    courseStmt.setString(2, course);
                    courseStmt.addBatch();
                }
                courseStmt.executeBatch();
            }

            conn.commit();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

}
