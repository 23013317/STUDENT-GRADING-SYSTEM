import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class CourseReportDatabaseFetcher {

    private Connection connection;

    public CourseReportDatabaseFetcher() {
        initializeDatabaseConnection();
    }

    private void initializeDatabaseConnection() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Map<String, CourseData> fetchCourseData() {
        Map<String, CourseData> courseDataMap = new HashMap<>();
        String query = "SELECT c.course_name, " +
                "AVG(g.test1) AS test1_avg, AVG(g.test2) AS test2_avg, AVG(g.assignment1) AS assign_avg, " +
                "AVG(g.semester_mark) AS semester_avg, AVG(g.exam_mark) AS exam_avg, AVG(g.final_mark) AS final_avg, " +
                "COUNT(g.student_id) AS students_enrolled " +
                "FROM courses c " +
                "JOIN grades g ON c.course_name = g.course " +
                "GROUP BY c.course_name";

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                String courseName = rs.getString("course_name");
                double test1Avg = rs.getDouble("test1_avg");
                double test2Avg = rs.getDouble("test2_avg");
                double assignAvg = rs.getDouble("assign_avg");
                double semesterAvg = rs.getDouble("semester_avg");
                double examAvg = rs.getDouble("exam_avg");
                double finalAvg = rs.getDouble("final_avg");
                int studentsEnrolled = rs.getInt("students_enrolled");

                courseDataMap.put(courseName, new CourseData(courseName, test1Avg, test2Avg, assignAvg, semesterAvg, examAvg, finalAvg, studentsEnrolled));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courseDataMap;
    }


    // Inner class to hold course data
    static class CourseData {
        String courseName;
        double test1Avg;
        double test2Avg;
        double assignAvg;
        double semesterAvg;
        double examAvg;
        double finalAvg;
        int studentsEnrolled;

        public CourseData(String courseName, double test1Avg, double test2Avg, double assignAvg, double semesterAvg, double examAvg, double finalAvg, int studentsEnrolled) {
            this.courseName = courseName;
            this.test1Avg = test1Avg;
            this.test2Avg = test2Avg;
            this.assignAvg = assignAvg;
            this.semesterAvg = semesterAvg;
            this.examAvg = examAvg;
            this.finalAvg = finalAvg;
            this.studentsEnrolled = studentsEnrolled;
        }
    }


}
