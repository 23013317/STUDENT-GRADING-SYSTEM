import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

    public class LoginFrame extends JFrame {
        private static JTextField usernameField;
        private JPasswordField passwordField;
        private JComboBox<String> roleComboBox;
        private JCheckBox showPasswordCheckBox;


        public LoginFrame(int StudentId){


        }
        public LoginFrame() {

            setTitle("STUDENT GRADING SYS_24 Login");
            setSize(1000,800);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            setLocationRelativeTo(null);


            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBackground(Color.darkGray);
//            ImageIcon image = new ImageIcon("src/Picture1.png");
//
//            JLabel picture=new JLabel("hey");
//            picture.setIcon(image);

//            panel.add(picture);

            JLabel userLabel = new JLabel("USERNAME");
            userLabel.setForeground(Color.WHITE);
            userLabel.setFocusable(true);
            panel.add(userLabel);



            usernameField = new JTextField();
            usernameField.setBackground(Color.lightGray);
            usernameField.setHorizontalAlignment(SwingConstants.CENTER);
            usernameField.setBorder(BorderFactory.createRaisedBevelBorder());
            panel.add(usernameField);

            JLabel passwordLabel = new JLabel("PASSWORD");
            passwordLabel.setForeground(Color.white);
            panel.add(passwordLabel);

            passwordField = new JPasswordField();
            passwordField.setBorder(BorderFactory.createRaisedBevelBorder());
            passwordField.setHorizontalAlignment(SwingConstants.CENTER);
            passwordField.setBackground(Color.lightGray);
            panel.add(passwordField);

//            picture.setBounds(400,0,150,150);
            userLabel.setBounds(425,200,100,30);
            usernameField.setBounds(350,250,200,30);
            passwordLabel.setBounds(425,300,100,30);
            passwordField.setBounds(350,350,200,30);


            showPasswordCheckBox = new JCheckBox("Show");
            showPasswordCheckBox.setBounds(350,400,100,30);
            showPasswordCheckBox.setBackground(Color.darkGray);
            showPasswordCheckBox.setForeground(Color.white);
            showPasswordCheckBox.setBorderPainted(true);

            showPasswordCheckBox.setFocusable(false);
            showPasswordCheckBox.addActionListener(e -> {
                if (showPasswordCheckBox.isSelected()) {
                    passwordField.setEchoChar((char) 0);
                } else {
                    passwordField.setEchoChar('*');
                }
            });

            panel.add(showPasswordCheckBox);
            JLabel roleLabel= new JLabel("Role:");
            roleLabel.setForeground(Color.WHITE);
            roleLabel.setBounds(450,400,100,30);
            panel.add(roleLabel);


            roleComboBox = new JComboBox<>(new String[]{"Student", "Lecture"});
            roleComboBox.setBackground(Color.lightGray);
            roleComboBox.setFocusable(false);
            roleComboBox.setBorder(BorderFactory.createRaisedBevelBorder());
            roleComboBox.setBounds(500,400,100,30);
            panel.add(roleComboBox);

            JButton loginButton = new JButton("LOGIN");
            loginButton.setBounds(350,500,200,30);
            loginButton.setFocusable(false);
            loginButton.setBackground(Color.darkGray);
            loginButton.setForeground(Color.white);
            loginButton.setBorder(BorderFactory.createRaisedBevelBorder());
            loginButton.addActionListener(new LoginButtonListener());
            panel.add(loginButton);

            JButton createStudentButton = new JButton("Register");
            createStudentButton.setBounds(350,550,200,30);
            createStudentButton.setBackground(Color.lightGray);

            createStudentButton.setBorder(BorderFactory.createRaisedBevelBorder());

            createStudentButton.addActionListener(e -> new CreateStudentFrame());
            panel.add(createStudentButton);
            add(panel);


            setVisible(true);
        }






        private class LoginButtonListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String role = (String) roleComboBox.getSelectedItem();

                if (checkPassword(username, password, role)) {
                    if (role.equals("Student")) {
                        new StudentFrame();
                    } else if (role.equals("Lecture")) {
                        new AdminFrame();
                    }
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(LoginFrame.this, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }

        private boolean checkPassword(String username, String password, String role) {
            String query = "";
            if (role.equals("Student")) {
                query = "SELECT * FROM students WHERE username = ? AND password = ?";
            } else if (role.equals("Lecture")) {
                query = "SELECT * FROM admins WHERE username = ? AND password = ?";
            }

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
                 PreparedStatement stmt = conn.prepareStatement(query)) {

                stmt.setString(1, username);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();

                return rs.next(); // Returns true if a match is found
            } catch (SQLException e) {
                e.printStackTrace();
                return false;
            }
        }



        public static String getLoggedUsername(){

            return usernameField.getText();

       }
    }