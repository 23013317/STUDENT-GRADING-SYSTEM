import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseFetcher {
    private Connection connection;

    public DatabaseFetcher() {
        try {
            // Establish database connection
            connection = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String> fetchEnrolledCourses(int studentId) {
        List<String> courses = new ArrayList<>();
        String query = "SELECT course_name FROM Enrollments WHERE student_id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();

            // Debug: Check if the query is executed
            System.out.println("Executing query: " + query);

            while (rs.next()) {
                String courseName = rs.getString("course_name");
                courses.add(courseName);
            }

            // Debug: Print the number of courses fetched
            System.out.println("Number of courses fetched: " + courses.size());

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courses;
    }

    public List<Object[]> fetchStudentGrades(int studentId, String courseName) {
        List<Object[]> grades = new ArrayList<>();
        String query = "SELECT test1, test2, assignment, semester_mark, exam_mark, final_mark FROM Grades WHERE student_id = ? AND course_name = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, courseName);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Object[] grade = {
                        rs.getInt("test1"),
                        rs.getInt("test2"),
                        rs.getInt("assignment"),
                        rs.getInt("semester_mark"),
                        rs.getInt("exam_mark"),
                        rs.getInt("final_mark")
                };
                grades.add(grade);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return grades;
    }
}

