import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ManageCoursesPanel extends JPanel {
    private JTextField courseNameField;
    private JTextField courseCreditsField;
    private JTextField courseDescriptionField;
    private JTable courseTable;
    private DefaultTableModel tableModel;

    public ManageCoursesPanel() {

        setLayout(new BorderLayout());

        // Top panel for input fields
        JPanel inputPanel = new JPanel(new GridLayout(4, 4));

        inputPanel.add(new JLabel("Course Name:"));
        courseNameField = new JTextField();
        inputPanel.add(courseNameField);

        inputPanel.add(new JLabel("Course Credits:"));

        courseDescriptionField = new JTextField();
        inputPanel.add(new JLabel("Course Description:"));
        inputPanel.add(courseDescriptionField);


        courseCreditsField = new JTextField();
        inputPanel.add(courseCreditsField);




        JButton addButton = new JButton("Add Course");
        addButton.setFocusable(false);
        addButton.setBackground(Color.lightGray);
        addButton.setForeground(Color.black);
        addButton.setBorder(BorderFactory.createRaisedBevelBorder());
        addButton.addActionListener(new AddButtonListener());
        inputPanel.add(addButton);

        JButton editButton = new JButton("Edit Course");
        editButton.setFocusable(false);
        editButton.setBackground(Color.lightGray);
        editButton.setForeground(Color.black);
        editButton.setBorder(BorderFactory.createRaisedBevelBorder());
        editButton.addActionListener(new EditButtonListener());
        inputPanel.add(editButton);

        JButton removeButton = new JButton("Remove Course");
        removeButton.setFocusable(false);
        removeButton.setBackground(Color.lightGray);
        removeButton.setForeground(Color.black);
        removeButton.setBorder(BorderFactory.createRaisedBevelBorder());
        removeButton.addActionListener(new RemoveButtonListener());
        inputPanel.add(removeButton);

        add(inputPanel, BorderLayout.NORTH);

        // Table for displaying courses
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Credits", "Description"}, 0);
        courseTable = new JTable(tableModel);
        loadCoursesFromDatabase();
        add(new JScrollPane(courseTable), BorderLayout.CENTER);
    }

    private void loadCoursesFromDatabase() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM courses")) {

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("course_name"),
                        rs.getInt("course_credits"),
                        rs.getString("course_description")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = courseNameField.getText();
            int credits = Integer.parseInt(courseCreditsField.getText());
            String description = courseDescriptionField.getText();

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
                 PreparedStatement stmt = conn.prepareStatement("INSERT INTO courses (course_name, course_credits, course_description) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {

                stmt.setString(1, name);
                stmt.setInt(2, credits);
                stmt.setString(3, description);
                stmt.executeUpdate();

                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    tableModel.addRow(new Object[]{id, name, credits, description});
                }
                clearFields();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private class EditButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = courseTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(ManageCoursesPanel.this, "Please select a course to edit.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int id = (int) tableModel.getValueAt(selectedRow, 0);
            String name = courseNameField.getText();
            int credits = Integer.parseInt(courseCreditsField.getText());
            String description = courseDescriptionField.getText();

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
                 PreparedStatement stmt = conn.prepareStatement("UPDATE courses SET course_name = ?, course_credits = ?, course_description = ? WHERE id = ?")) {

                stmt.setString(1, name);
                stmt.setInt(2, credits);
                stmt.setString(3, description);
                stmt.setInt(4, id);
                stmt.executeUpdate();

                tableModel.setValueAt(name, selectedRow, 1);
                tableModel.setValueAt(credits, selectedRow, 2);
                tableModel.setValueAt(description, selectedRow, 3);
                clearFields();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private class RemoveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = courseTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(ManageCoursesPanel.this, "Please select a course to remove.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int id = (int) tableModel.getValueAt(selectedRow, 0);

            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:studentgradingdatabase.db");
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM courses WHERE id = ?")) {

                stmt.setInt(1, id);
                stmt.executeUpdate();

                tableModel.removeRow(selectedRow);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void clearFields() {
        courseNameField.setText("");
        courseCreditsField.setText("");
        courseDescriptionField.setText("");
    }
}
