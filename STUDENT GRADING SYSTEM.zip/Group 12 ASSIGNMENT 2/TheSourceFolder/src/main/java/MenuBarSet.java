import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

    public class MenuBarSet {

        public static void addMenuBar(JFrame frame) {
            JMenuBar menuBar = new JMenuBar();
            menuBar.setBackground(Color.lightGray);
            JMenu menu = new JMenu("Exit");
            JMenuItem logoutMenuItem = new JMenuItem("Logout");
            logoutMenuItem.setBackground(Color.lightGray);
            menu.add(logoutMenuItem);
            menuBar.add(menu);

            frame.setJMenuBar(menuBar);

            logoutMenuItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    new LoginFrame();
                    frame.dispose();
                }
            });
        }

    }

